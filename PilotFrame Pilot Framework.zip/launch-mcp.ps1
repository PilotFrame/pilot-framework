Set-Location -Path "C:\Dev\BytesFromAli\pf-framework\mcp-server"
node dist/index.js

