declare module '@schema' {
  const schema: Record<string, unknown>;
  export default schema;
}

